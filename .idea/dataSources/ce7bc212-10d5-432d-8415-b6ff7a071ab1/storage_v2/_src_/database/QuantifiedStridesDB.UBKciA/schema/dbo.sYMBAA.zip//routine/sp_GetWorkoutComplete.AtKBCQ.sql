
CREATE PROCEDURE sp_GetWorkoutComplete
    @WorkoutID INT
AS
BEGIN
    -- Get workout summary
    SELECT * FROM Workouts_v2 WHERE WorkoutID = @WorkoutID;
    
    -- Get time-series metrics
    SELECT * FROM WorkoutMetrics_v2 
    WHERE WorkoutID = @WorkoutID 
    ORDER BY ElapsedSeconds;
    
    -- Get metric descriptors
    SELECT * FROM MetricDescriptorCache 
    WHERE WorkoutID = @WorkoutID 
    ORDER BY MetricIndex;
    
    -- Get raw JSON if available
    SELECT MetricDescriptors, TotalPoints, DataChecksum 
    FROM WorkoutMetricsRaw 
    WHERE WorkoutID = @WorkoutID;
END;
go

