
--1/d)
CREATE PROCEDURE AddColumn(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128),
	@ColumnType VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' ADD ' + @ColumnName + ' ' + @ColumnType;
	PRINT @SQL;
	EXEC(@SQL);
END;

go

