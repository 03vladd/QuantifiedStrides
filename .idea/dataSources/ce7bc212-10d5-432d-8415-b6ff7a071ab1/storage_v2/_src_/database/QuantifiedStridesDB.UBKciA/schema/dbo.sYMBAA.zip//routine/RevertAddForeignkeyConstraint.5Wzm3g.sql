
CREATE PROCEDURE RevertAddForeignkeyConstraint(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' DROP CONSTRAINT FK_' + @TableName + '_' + @ColumnName;
	PRINT @SQL;
	EXEC(@SQL);
END;

go

