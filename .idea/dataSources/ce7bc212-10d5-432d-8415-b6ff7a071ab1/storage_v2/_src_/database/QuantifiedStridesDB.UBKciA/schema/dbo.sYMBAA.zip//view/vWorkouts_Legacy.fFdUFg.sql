
    CREATE VIEW vWorkouts_Legacy AS
    SELECT 
        WorkoutID,
        UserID,
        Sport,
        StartTime,
        EndTime,
        WorkoutType,
        CaloriesBurned,
        AvgHeartRate,
        MaxHeartRate,
        VO2MaxEstimate,
        LactateThresholdBpm,
        TimeInHRZone1,
        TimeInHRZone2,
        TimeInHRZone3,
        TimeInHRZone4,
        TimeInHRZone5,
        DistanceMeters AS TrainingVolume,
        AvgVerticalOscillation,
        AvgGroundContactTime,
        AvgStrideLength,
        AvgVerticalRatio,
        AvgRunningCadence AS AverageRunningCadence,
        MaxRunningCadence,
        Location,
        WorkoutDate,
        IsIndoor
    FROM Workouts_v2

    go

