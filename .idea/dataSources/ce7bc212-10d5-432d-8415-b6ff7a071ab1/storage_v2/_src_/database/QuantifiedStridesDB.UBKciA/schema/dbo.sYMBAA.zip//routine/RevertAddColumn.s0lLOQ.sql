
CREATE PROCEDURE RevertAddColumn(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' DROP COLUMN ' + @ColumnName;
	PRINT @SQL;
	EXEC(@SQL);
END;

go

