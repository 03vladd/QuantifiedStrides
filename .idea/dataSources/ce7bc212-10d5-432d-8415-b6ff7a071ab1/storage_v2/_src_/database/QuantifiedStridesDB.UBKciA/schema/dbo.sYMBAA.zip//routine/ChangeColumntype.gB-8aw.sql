--1/a)
CREATE PROCEDURE ChangeColumntype(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128),
	@NewDataType VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' ALTER COLUMN ' + @ColumnName + ' ' + @NewDataType;
	EXEC(@SQL);
END;

go

