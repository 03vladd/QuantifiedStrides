
CREATE PROCEDURE sp_SearchWorkouts
    @UserID INT,
    @Sport VARCHAR(50) = NULL,
    @StartDate DATE = NULL,
    @EndDate DATE = NULL,
    @MinDistance FLOAT = NULL,
    @IsIndoor BIT = NULL
AS
BEGIN
    SELECT 
        WorkoutID,
        ActivityID,
        Sport,
        WorkoutType,
        WorkoutDate,
        DurationSeconds,
        DistanceMeters,
        CaloriesBurned,
        AvgHeartRate,
        Location,
        IsIndoor
    FROM Workouts_v2
    WHERE UserID = @UserID
        AND (@Sport IS NULL OR Sport = @Sport)
        AND (@StartDate IS NULL OR WorkoutDate >= @StartDate)
        AND (@EndDate IS NULL OR WorkoutDate <= @EndDate)
        AND (@MinDistance IS NULL OR DistanceMeters >= @MinDistance)
        AND (@IsIndoor IS NULL OR IsIndoor = @IsIndoor)
    ORDER BY WorkoutDate DESC;
END;
go

