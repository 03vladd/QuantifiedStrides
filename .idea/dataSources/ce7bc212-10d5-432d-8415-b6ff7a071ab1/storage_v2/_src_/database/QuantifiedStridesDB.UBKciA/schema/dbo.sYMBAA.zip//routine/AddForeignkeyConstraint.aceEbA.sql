
--1/e)
CREATE PROCEDURE AddForeignkeyConstraint(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128),
	@ReferencedTable VARCHAR(128),
	@ReferencedColumn VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' ADD CONSTRAINT FK_' + @TableName + '_' + @ColumnName +
			   ' FOREIGN KEY (' + @ColumnName + ') REFERENCES ' + @ReferencedTable + '(' + @ReferencedColumn + ')';
	PRINT @SQL;
	EXEC(@SQL);
END;

go

