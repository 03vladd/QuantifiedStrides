
CREATE PROCEDURE RevertCreateDefaultConstraint(
	@TableName VARCHAR(128),
	@columnName VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' DROP CONSTRAINT DF_' + @TableName + '_' + @columnName;
	PRINT @SQL;
	EXEC(@SQL);
END;

go

