
--1/b)
CREATE PROCEDURE CreateDefaultConstraint(
	@TableName VARCHAR(128),
	@ColumnName VARCHAR(128),
	@DefaultValue VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = 'ALTER TABLE ' + @TableName + ' ADD CONSTRAINT DF_' + @TableName + '_' + 
			   @ColumnName + ' DEFAULT ''' + @DefaultValue + ''' FOR ' + @ColumnName;
	PRINT @SQL;
	EXEC (@SQL);
END;

go

