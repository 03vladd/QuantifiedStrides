
--1/c)
CREATE PROCEDURE CreateTable(
	@TableName VARCHAR(128),
	@Columns VARCHAR(128)
) AS
BEGIN
	DECLARE @SQL VARCHAR(MAX);
	SET @SQL = ' CREATE TABLE ' + @TableName + ' (' + @Columns + ')';
	PRINT @SQL;
	EXEC(@SQL);
END;

go

